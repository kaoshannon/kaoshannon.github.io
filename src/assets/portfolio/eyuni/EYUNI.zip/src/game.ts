import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../7e78cd70-5414-4ec4-be5f-198ec9879a5e/src/item"
import Script2 from "../a747f104-5434-42a8-a543-8739c24cf253/src/item"
import Script3 from "../ab743f36-176b-4e74-897e-19e28cc6e425/src/item"
import Script4 from "../0ee46c79-338c-445a-a506-ea26d80fbe46/src/item"
import Script5 from "../76c9399b-8207-4d82-82fd-3ec792d1fbbb/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const floorLightDisc = new Entity('floorLightDisc')
engine.addEntity(floorLightDisc)
floorLightDisc.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5, 1, 5.000000953674316)
})
floorLightDisc.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("0845fe62-9876-4e6a-a9c2-e001667c455b/Light_04/Light_04.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
floorLightDisc.addComponentOrReplace(gltfShape)

const blueLightPagoda = new Entity('blueLightPagoda')
engine.addEntity(blueLightPagoda)
blueLightPagoda.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(11.25, 7, 11.25)
})
blueLightPagoda.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("d9bd15c5-8c18-44bc-a574-1aeff9c8e580/LightCylinder_02/LightCylinder_02.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
blueLightPagoda.addComponentOrReplace(gltfShape2)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape3 = new GLTFShape("6b33f46e-9667-45e5-bd90-85f372ee2490/CityTile.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
entity.addComponentOrReplace(gltfShape3)
const transform4 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform4)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape3)
const transform5 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform5)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape3)
const transform6 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform6)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape3)
const transform7 = new Transform({
  position: new Vector3(56, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform7)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape3)
const transform8 = new Transform({
  position: new Vector3(72, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform8)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape3)
const transform9 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform9)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape3)
const transform10 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform10)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape3)
const transform11 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform11)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape3)
const transform12 = new Transform({
  position: new Vector3(56, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform12)

const entity10 = new Entity('entity10')
engine.addEntity(entity10)
entity10.setParent(_scene)
entity10.addComponentOrReplace(gltfShape3)
const transform13 = new Transform({
  position: new Vector3(72, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity10.addComponentOrReplace(transform13)

const entity11 = new Entity('entity11')
engine.addEntity(entity11)
entity11.setParent(_scene)
entity11.addComponentOrReplace(gltfShape3)
const transform14 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity11.addComponentOrReplace(transform14)

const entity12 = new Entity('entity12')
engine.addEntity(entity12)
entity12.setParent(_scene)
entity12.addComponentOrReplace(gltfShape3)
const transform15 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity12.addComponentOrReplace(transform15)

const entity13 = new Entity('entity13')
engine.addEntity(entity13)
entity13.setParent(_scene)
entity13.addComponentOrReplace(gltfShape3)
const transform16 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity13.addComponentOrReplace(transform16)

const entity14 = new Entity('entity14')
engine.addEntity(entity14)
entity14.setParent(_scene)
entity14.addComponentOrReplace(gltfShape3)
const transform17 = new Transform({
  position: new Vector3(56, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity14.addComponentOrReplace(transform17)

const entity15 = new Entity('entity15')
engine.addEntity(entity15)
entity15.setParent(_scene)
entity15.addComponentOrReplace(gltfShape3)
const transform18 = new Transform({
  position: new Vector3(72, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity15.addComponentOrReplace(transform18)

const entity16 = new Entity('entity16')
engine.addEntity(entity16)
entity16.setParent(_scene)
entity16.addComponentOrReplace(gltfShape3)
const transform19 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity16.addComponentOrReplace(transform19)

const entity17 = new Entity('entity17')
engine.addEntity(entity17)
entity17.setParent(_scene)
entity17.addComponentOrReplace(gltfShape3)
const transform20 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity17.addComponentOrReplace(transform20)

const entity18 = new Entity('entity18')
engine.addEntity(entity18)
entity18.setParent(_scene)
entity18.addComponentOrReplace(gltfShape3)
const transform21 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity18.addComponentOrReplace(transform21)

const entity19 = new Entity('entity19')
engine.addEntity(entity19)
entity19.setParent(_scene)
entity19.addComponentOrReplace(gltfShape3)
const transform22 = new Transform({
  position: new Vector3(56, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity19.addComponentOrReplace(transform22)

const entity20 = new Entity('entity20')
engine.addEntity(entity20)
entity20.setParent(_scene)
entity20.addComponentOrReplace(gltfShape3)
const transform23 = new Transform({
  position: new Vector3(72, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity20.addComponentOrReplace(transform23)

const entity21 = new Entity('entity21')
engine.addEntity(entity21)
entity21.setParent(_scene)
entity21.addComponentOrReplace(gltfShape3)
const transform24 = new Transform({
  position: new Vector3(8, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity21.addComponentOrReplace(transform24)

const entity22 = new Entity('entity22')
engine.addEntity(entity22)
entity22.setParent(_scene)
entity22.addComponentOrReplace(gltfShape3)
const transform25 = new Transform({
  position: new Vector3(24, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity22.addComponentOrReplace(transform25)

const entity23 = new Entity('entity23')
engine.addEntity(entity23)
entity23.setParent(_scene)
entity23.addComponentOrReplace(gltfShape3)
const transform26 = new Transform({
  position: new Vector3(40, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity23.addComponentOrReplace(transform26)

const entity24 = new Entity('entity24')
engine.addEntity(entity24)
entity24.setParent(_scene)
entity24.addComponentOrReplace(gltfShape3)
const transform27 = new Transform({
  position: new Vector3(56, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity24.addComponentOrReplace(transform27)

const entity25 = new Entity('entity25')
engine.addEntity(entity25)
entity25.setParent(_scene)
entity25.addComponentOrReplace(gltfShape3)
const transform28 = new Transform({
  position: new Vector3(72, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity25.addComponentOrReplace(transform28)

const hexagonalFloorPanel2 = new Entity('hexagonalFloorPanel2')
engine.addEntity(hexagonalFloorPanel2)
hexagonalFloorPanel2.setParent(_scene)
const gltfShape4 = new GLTFShape("0e8a19d7-392f-434a-bf32-e8dc932cba81/FloorHexa_01/FloorHexa_01.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
hexagonalFloorPanel2.addComponentOrReplace(gltfShape4)
const transform29 = new Transform({
  position: new Vector3(40, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel2.addComponentOrReplace(transform29)

const domeGreenhouse = new Entity('domeGreenhouse')
engine.addEntity(domeGreenhouse)
domeGreenhouse.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(68, 0, 40),
  rotation: new Quaternion(-1.7895294722794757e-15, 0.7071068286895752, -8.42937097900176e-8, -0.7071068286895752),
  scale: new Vector3(2.5, 2, 2.5)
})
domeGreenhouse.addComponentOrReplace(transform30)
const gltfShape5 = new GLTFShape("66a1b927-de0d-4114-9ae0-e8b485601040/GreenHouse_01/GreenHouse_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
domeGreenhouse.addComponentOrReplace(gltfShape5)

const lampPost = new Entity('lampPost')
engine.addEntity(lampPost)
lampPost.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(43.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost.addComponentOrReplace(transform31)
const gltfShape6 = new GLTFShape("ac343262-ae62-45d1-8f17-0e01a9591992/LampPostSciFi_01/LampPostSciFi_01.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
lampPost.addComponentOrReplace(gltfShape6)

const teleporterBase = new Entity('teleporterBase')
engine.addEntity(teleporterBase)
teleporterBase.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(47, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
teleporterBase.addComponentOrReplace(transform32)
const gltfShape7 = new GLTFShape("20e35437-2ae3-41f0-a99e-429b7c8c6bf2/Teleporter_01/Teleporter_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
teleporterBase.addComponentOrReplace(gltfShape7)

const hexagonalFloorPanel = new Entity('hexagonalFloorPanel')
engine.addEntity(hexagonalFloorPanel)
hexagonalFloorPanel.setParent(_scene)
hexagonalFloorPanel.addComponentOrReplace(gltfShape4)
const transform33 = new Transform({
  position: new Vector3(38, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel.addComponentOrReplace(transform33)

const hexagonalFloorPanel3 = new Entity('hexagonalFloorPanel3')
engine.addEntity(hexagonalFloorPanel3)
hexagonalFloorPanel3.setParent(_scene)
hexagonalFloorPanel3.addComponentOrReplace(gltfShape4)
const transform34 = new Transform({
  position: new Vector3(42, 0, 15.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel3.addComponentOrReplace(transform34)

const hexagonalFloorPanel4 = new Entity('hexagonalFloorPanel4')
engine.addEntity(hexagonalFloorPanel4)
hexagonalFloorPanel4.setParent(_scene)
hexagonalFloorPanel4.addComponentOrReplace(gltfShape4)
const transform35 = new Transform({
  position: new Vector3(39, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel4.addComponentOrReplace(transform35)

const hexagonalFloorPanel5 = new Entity('hexagonalFloorPanel5')
engine.addEntity(hexagonalFloorPanel5)
hexagonalFloorPanel5.setParent(_scene)
hexagonalFloorPanel5.addComponentOrReplace(gltfShape4)
const transform36 = new Transform({
  position: new Vector3(41, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel5.addComponentOrReplace(transform36)

const halfHexFloorPanel = new Entity('halfHexFloorPanel')
engine.addEntity(halfHexFloorPanel)
halfHexFloorPanel.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(37, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel.addComponentOrReplace(transform37)
const gltfShape8 = new GLTFShape("a14f1390-1c37-4fe1-affc-7c4616bfb9c4/FloorHexa_02/FloorHexa_02.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
halfHexFloorPanel.addComponentOrReplace(gltfShape8)

const halfHexFloorPanel2 = new Entity('halfHexFloorPanel2')
engine.addEntity(halfHexFloorPanel2)
halfHexFloorPanel2.setParent(_scene)
halfHexFloorPanel2.addComponentOrReplace(gltfShape8)
const transform38 = new Transform({
  position: new Vector3(43, 0, 17),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel2.addComponentOrReplace(transform38)

const halfHexFloorPanel3 = new Entity('halfHexFloorPanel3')
engine.addEntity(halfHexFloorPanel3)
halfHexFloorPanel3.setParent(_scene)
halfHexFloorPanel3.addComponentOrReplace(gltfShape8)
const transform39 = new Transform({
  position: new Vector3(37, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel3.addComponentOrReplace(transform39)

const halfHexFloorPanel4 = new Entity('halfHexFloorPanel4')
engine.addEntity(halfHexFloorPanel4)
halfHexFloorPanel4.setParent(_scene)
halfHexFloorPanel4.addComponentOrReplace(gltfShape8)
const transform40 = new Transform({
  position: new Vector3(43, 0, 14),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel4.addComponentOrReplace(transform40)

const hexagonalFloorPanel6 = new Entity('hexagonalFloorPanel6')
engine.addEntity(hexagonalFloorPanel6)
hexagonalFloorPanel6.setParent(_scene)
hexagonalFloorPanel6.addComponentOrReplace(gltfShape4)
const transform41 = new Transform({
  position: new Vector3(39, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel6.addComponentOrReplace(transform41)

const hexagonalFloorPanel7 = new Entity('hexagonalFloorPanel7')
engine.addEntity(hexagonalFloorPanel7)
hexagonalFloorPanel7.setParent(_scene)
hexagonalFloorPanel7.addComponentOrReplace(gltfShape4)
const transform42 = new Transform({
  position: new Vector3(41, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel7.addComponentOrReplace(transform42)

const hexagonalFloorPanel8 = new Entity('hexagonalFloorPanel8')
engine.addEntity(hexagonalFloorPanel8)
hexagonalFloorPanel8.setParent(_scene)
hexagonalFloorPanel8.addComponentOrReplace(gltfShape4)
const transform43 = new Transform({
  position: new Vector3(42, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel8.addComponentOrReplace(transform43)

const hexagonalFloorPanel9 = new Entity('hexagonalFloorPanel9')
engine.addEntity(hexagonalFloorPanel9)
hexagonalFloorPanel9.setParent(_scene)
hexagonalFloorPanel9.addComponentOrReplace(gltfShape4)
const transform44 = new Transform({
  position: new Vector3(40, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel9.addComponentOrReplace(transform44)

const hexagonalFloorPanel10 = new Entity('hexagonalFloorPanel10')
engine.addEntity(hexagonalFloorPanel10)
hexagonalFloorPanel10.setParent(_scene)
hexagonalFloorPanel10.addComponentOrReplace(gltfShape4)
const transform45 = new Transform({
  position: new Vector3(38, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel10.addComponentOrReplace(transform45)

const hexagonalFloorPanel11 = new Entity('hexagonalFloorPanel11')
engine.addEntity(hexagonalFloorPanel11)
hexagonalFloorPanel11.setParent(_scene)
hexagonalFloorPanel11.addComponentOrReplace(gltfShape4)
const transform46 = new Transform({
  position: new Vector3(39, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel11.addComponentOrReplace(transform46)

const hexagonalFloorPanel12 = new Entity('hexagonalFloorPanel12')
engine.addEntity(hexagonalFloorPanel12)
hexagonalFloorPanel12.setParent(_scene)
hexagonalFloorPanel12.addComponentOrReplace(gltfShape4)
const transform47 = new Transform({
  position: new Vector3(41, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel12.addComponentOrReplace(transform47)

const hexagonalFloorPanel13 = new Entity('hexagonalFloorPanel13')
engine.addEntity(hexagonalFloorPanel13)
hexagonalFloorPanel13.setParent(_scene)
hexagonalFloorPanel13.addComponentOrReplace(gltfShape4)
const transform48 = new Transform({
  position: new Vector3(40, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel13.addComponentOrReplace(transform48)

const halfHexFloorPanel5 = new Entity('halfHexFloorPanel5')
engine.addEntity(halfHexFloorPanel5)
halfHexFloorPanel5.setParent(_scene)
halfHexFloorPanel5.addComponentOrReplace(gltfShape8)
const transform49 = new Transform({
  position: new Vector3(43, 0, 11),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel5.addComponentOrReplace(transform49)

const halfHexFloorPanel6 = new Entity('halfHexFloorPanel6')
engine.addEntity(halfHexFloorPanel6)
halfHexFloorPanel6.setParent(_scene)
halfHexFloorPanel6.addComponentOrReplace(gltfShape8)
const transform50 = new Transform({
  position: new Vector3(37, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel6.addComponentOrReplace(transform50)

const hexagonalFloorPanel14 = new Entity('hexagonalFloorPanel14')
engine.addEntity(hexagonalFloorPanel14)
hexagonalFloorPanel14.setParent(_scene)
hexagonalFloorPanel14.addComponentOrReplace(gltfShape4)
const transform51 = new Transform({
  position: new Vector3(40, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel14.addComponentOrReplace(transform51)

const hexagonalFloorPanel15 = new Entity('hexagonalFloorPanel15')
engine.addEntity(hexagonalFloorPanel15)
hexagonalFloorPanel15.setParent(_scene)
hexagonalFloorPanel15.addComponentOrReplace(gltfShape4)
const transform52 = new Transform({
  position: new Vector3(42, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel15.addComponentOrReplace(transform52)

const hexagonalFloorPanel16 = new Entity('hexagonalFloorPanel16')
engine.addEntity(hexagonalFloorPanel16)
hexagonalFloorPanel16.setParent(_scene)
hexagonalFloorPanel16.addComponentOrReplace(gltfShape4)
const transform53 = new Transform({
  position: new Vector3(38, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel16.addComponentOrReplace(transform53)

const halfHexFloorPanel7 = new Entity('halfHexFloorPanel7')
engine.addEntity(halfHexFloorPanel7)
halfHexFloorPanel7.setParent(_scene)
halfHexFloorPanel7.addComponentOrReplace(gltfShape8)
const transform54 = new Transform({
  position: new Vector3(37, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel7.addComponentOrReplace(transform54)

const halfHexFloorPanel8 = new Entity('halfHexFloorPanel8')
engine.addEntity(halfHexFloorPanel8)
halfHexFloorPanel8.setParent(_scene)
halfHexFloorPanel8.addComponentOrReplace(gltfShape8)
const transform55 = new Transform({
  position: new Vector3(43, 0, 8),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel8.addComponentOrReplace(transform55)

const hexagonalFloorPanel17 = new Entity('hexagonalFloorPanel17')
engine.addEntity(hexagonalFloorPanel17)
hexagonalFloorPanel17.setParent(_scene)
hexagonalFloorPanel17.addComponentOrReplace(gltfShape4)
const transform56 = new Transform({
  position: new Vector3(39, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel17.addComponentOrReplace(transform56)

const hexagonalFloorPanel18 = new Entity('hexagonalFloorPanel18')
engine.addEntity(hexagonalFloorPanel18)
hexagonalFloorPanel18.setParent(_scene)
hexagonalFloorPanel18.addComponentOrReplace(gltfShape4)
const transform57 = new Transform({
  position: new Vector3(41, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel18.addComponentOrReplace(transform57)

const hexagonalFloorPanel19 = new Entity('hexagonalFloorPanel19')
engine.addEntity(hexagonalFloorPanel19)
hexagonalFloorPanel19.setParent(_scene)
hexagonalFloorPanel19.addComponentOrReplace(gltfShape4)
const transform58 = new Transform({
  position: new Vector3(42, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel19.addComponentOrReplace(transform58)

const hexagonalFloorPanel20 = new Entity('hexagonalFloorPanel20')
engine.addEntity(hexagonalFloorPanel20)
hexagonalFloorPanel20.setParent(_scene)
hexagonalFloorPanel20.addComponentOrReplace(gltfShape4)
const transform59 = new Transform({
  position: new Vector3(40, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel20.addComponentOrReplace(transform59)

const hexagonalFloorPanel21 = new Entity('hexagonalFloorPanel21')
engine.addEntity(hexagonalFloorPanel21)
hexagonalFloorPanel21.setParent(_scene)
hexagonalFloorPanel21.addComponentOrReplace(gltfShape4)
const transform60 = new Transform({
  position: new Vector3(38, 0, 6.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel21.addComponentOrReplace(transform60)

const halfHexFloorPanel9 = new Entity('halfHexFloorPanel9')
engine.addEntity(halfHexFloorPanel9)
halfHexFloorPanel9.setParent(_scene)
halfHexFloorPanel9.addComponentOrReplace(gltfShape8)
const transform61 = new Transform({
  position: new Vector3(37, 0, 5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel9.addComponentOrReplace(transform61)

const halfHexFloorPanel10 = new Entity('halfHexFloorPanel10')
engine.addEntity(halfHexFloorPanel10)
halfHexFloorPanel10.setParent(_scene)
halfHexFloorPanel10.addComponentOrReplace(gltfShape8)
const transform62 = new Transform({
  position: new Vector3(43, 0, 5),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel10.addComponentOrReplace(transform62)

const hexagonalFloorPanel22 = new Entity('hexagonalFloorPanel22')
engine.addEntity(hexagonalFloorPanel22)
hexagonalFloorPanel22.setParent(_scene)
hexagonalFloorPanel22.addComponentOrReplace(gltfShape4)
const transform63 = new Transform({
  position: new Vector3(41, 0, 5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel22.addComponentOrReplace(transform63)

const hexagonalFloorPanel23 = new Entity('hexagonalFloorPanel23')
engine.addEntity(hexagonalFloorPanel23)
hexagonalFloorPanel23.setParent(_scene)
hexagonalFloorPanel23.addComponentOrReplace(gltfShape4)
const transform64 = new Transform({
  position: new Vector3(39, 0, 5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel23.addComponentOrReplace(transform64)

const hexagonalFloorPanel24 = new Entity('hexagonalFloorPanel24')
engine.addEntity(hexagonalFloorPanel24)
hexagonalFloorPanel24.setParent(_scene)
hexagonalFloorPanel24.addComponentOrReplace(gltfShape4)
const transform65 = new Transform({
  position: new Vector3(40, 0, 3.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel24.addComponentOrReplace(transform65)

const hexagonalFloorPanel25 = new Entity('hexagonalFloorPanel25')
engine.addEntity(hexagonalFloorPanel25)
hexagonalFloorPanel25.setParent(_scene)
hexagonalFloorPanel25.addComponentOrReplace(gltfShape4)
const transform66 = new Transform({
  position: new Vector3(42, 0, 3.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel25.addComponentOrReplace(transform66)

const hexagonalFloorPanel26 = new Entity('hexagonalFloorPanel26')
engine.addEntity(hexagonalFloorPanel26)
hexagonalFloorPanel26.setParent(_scene)
hexagonalFloorPanel26.addComponentOrReplace(gltfShape4)
const transform67 = new Transform({
  position: new Vector3(38, 0, 3.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel26.addComponentOrReplace(transform67)

const hexagonalFloorPanel27 = new Entity('hexagonalFloorPanel27')
engine.addEntity(hexagonalFloorPanel27)
hexagonalFloorPanel27.setParent(_scene)
hexagonalFloorPanel27.addComponentOrReplace(gltfShape4)
const transform68 = new Transform({
  position: new Vector3(39, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel27.addComponentOrReplace(transform68)

const hexagonalFloorPanel28 = new Entity('hexagonalFloorPanel28')
engine.addEntity(hexagonalFloorPanel28)
hexagonalFloorPanel28.setParent(_scene)
hexagonalFloorPanel28.addComponentOrReplace(gltfShape4)
const transform69 = new Transform({
  position: new Vector3(41, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel28.addComponentOrReplace(transform69)

const halfHexFloorPanel11 = new Entity('halfHexFloorPanel11')
engine.addEntity(halfHexFloorPanel11)
halfHexFloorPanel11.setParent(_scene)
halfHexFloorPanel11.addComponentOrReplace(gltfShape8)
const transform70 = new Transform({
  position: new Vector3(37, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel11.addComponentOrReplace(transform70)

const halfHexFloorPanel12 = new Entity('halfHexFloorPanel12')
engine.addEntity(halfHexFloorPanel12)
halfHexFloorPanel12.setParent(_scene)
halfHexFloorPanel12.addComponentOrReplace(gltfShape8)
const transform71 = new Transform({
  position: new Vector3(43, 0, 2),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel12.addComponentOrReplace(transform71)

const lampPost2 = new Entity('lampPost2')
engine.addEntity(lampPost2)
lampPost2.setParent(_scene)
lampPost2.addComponentOrReplace(gltfShape6)
const transform72 = new Transform({
  position: new Vector3(36.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost2.addComponentOrReplace(transform72)

const lampPost3 = new Entity('lampPost3')
engine.addEntity(lampPost3)
lampPost3.setParent(_scene)
lampPost3.addComponentOrReplace(gltfShape6)
const transform73 = new Transform({
  position: new Vector3(43.5, 0, 5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost3.addComponentOrReplace(transform73)

const lampPost4 = new Entity('lampPost4')
engine.addEntity(lampPost4)
lampPost4.setParent(_scene)
lampPost4.addComponentOrReplace(gltfShape6)
const transform74 = new Transform({
  position: new Vector3(36.5, 0, 5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost4.addComponentOrReplace(transform74)

const lampPost5 = new Entity('lampPost5')
engine.addEntity(lampPost5)
lampPost5.setParent(_scene)
lampPost5.addComponentOrReplace(gltfShape6)
const transform75 = new Transform({
  position: new Vector3(36.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost5.addComponentOrReplace(transform75)

const lampPost6 = new Entity('lampPost6')
engine.addEntity(lampPost6)
lampPost6.setParent(_scene)
lampPost6.addComponentOrReplace(gltfShape6)
const transform76 = new Transform({
  position: new Vector3(43.5, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost6.addComponentOrReplace(transform76)

const lampPost7 = new Entity('lampPost7')
engine.addEntity(lampPost7)
lampPost7.setParent(_scene)
lampPost7.addComponentOrReplace(gltfShape6)
const transform77 = new Transform({
  position: new Vector3(43.5, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost7.addComponentOrReplace(transform77)

const lampPost8 = new Entity('lampPost8')
engine.addEntity(lampPost8)
lampPost8.setParent(_scene)
lampPost8.addComponentOrReplace(gltfShape6)
const transform78 = new Transform({
  position: new Vector3(36.5, 0, 11),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost8.addComponentOrReplace(transform78)

const lampPost9 = new Entity('lampPost9')
engine.addEntity(lampPost9)
lampPost9.setParent(_scene)
lampPost9.addComponentOrReplace(gltfShape6)
const transform79 = new Transform({
  position: new Vector3(43.5, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost9.addComponentOrReplace(transform79)

const lampPost10 = new Entity('lampPost10')
engine.addEntity(lampPost10)
lampPost10.setParent(_scene)
lampPost10.addComponentOrReplace(gltfShape6)
const transform80 = new Transform({
  position: new Vector3(36.5, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost10.addComponentOrReplace(transform80)

const yellowDinnerTable = new Entity('yellowDinnerTable')
engine.addEntity(yellowDinnerTable)
yellowDinnerTable.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(65.5, 0.5, 47.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
yellowDinnerTable.addComponentOrReplace(transform81)
const gltfShape9 = new GLTFShape("87383b74-7a88-4722-b298-fd1fb0444a77/TableSciFi_02/TableSciFi_02.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
yellowDinnerTable.addComponentOrReplace(gltfShape9)

const tieredDesk = new Entity('tieredDesk')
engine.addEntity(tieredDesk)
tieredDesk.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(74, 0.5, 45),
  rotation: new Quaternion(-3.672398163698113e-15, -0.8819212913513184, 1.0513321058169822e-7, 0.47139671444892883),
  scale: new Vector3(1.0000008344650269, 1, 1.0000008344650269)
})
tieredDesk.addComponentOrReplace(transform82)
const gltfShape10 = new GLTFShape("337f9d3d-cd76-4172-9f54-16c64a348734/Desk_01/Desk_01.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
tieredDesk.addComponentOrReplace(gltfShape10)

const monitorScreen = new Entity('monitorScreen')
engine.addEntity(monitorScreen)
monitorScreen.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(70, 1.5, 46.5),
  rotation: new Quaternion(6.230862451429148e-15, -0.9238796234130859, 1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.000003457069397, 1, 1.000003457069397)
})
monitorScreen.addComponentOrReplace(transform83)
const gltfShape11 = new GLTFShape("2f77ba2c-b377-49d7-a00d-76d7def4d52e/Monitor_01/Monitor_01.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
monitorScreen.addComponentOrReplace(gltfShape11)

const foldingChair = new Entity('foldingChair')
engine.addEntity(foldingChair)
foldingChair.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(70, 0.5, 46),
  rotation: new Quaternion(8.754096627180627e-16, -0.8819213509559631, 1.0513320347627086e-7, 0.47139665484428406),
  scale: new Vector3(1.0000003576278687, 1, 1.0000003576278687)
})
foldingChair.addComponentOrReplace(transform84)
const gltfShape12 = new GLTFShape("e31c1ffb-0712-44f5-9e55-b74a73d077d4/Chair_01/Chair_01.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
foldingChair.addComponentOrReplace(gltfShape12)

const computerWide = new Entity('computerWide')
engine.addEntity(computerWide)
computerWide.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(67.5, 0, 30.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
computerWide.addComponentOrReplace(transform85)
const gltfShape13 = new GLTFShape("7c6f5b1a-02af-4edd-9f2c-c9c653eadf92/Computer_02/Computer_02.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
computerWide.addComponentOrReplace(gltfShape13)

const commandConsole = new Entity('commandConsole')
engine.addEntity(commandConsole)
commandConsole.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(75.5, 0.5, 40),
  rotation: new Quaternion(-1.9455749640203465e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000004768371582, 1, 1.0000004768371582)
})
commandConsole.addComponentOrReplace(transform86)
const gltfShape14 = new GLTFShape("614f3ed5-6524-4c86-96ff-e94eee731ee9/CommandControl_01/CommandControl_01.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
commandConsole.addComponentOrReplace(gltfShape14)

const computerThin = new Entity('computerThin')
engine.addEntity(computerThin)
computerThin.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(69, 0, 30.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
computerThin.addComponentOrReplace(transform87)
const gltfShape15 = new GLTFShape("8c1def81-f26c-4514-9423-4e621026a627/Computer_01/Computer_01.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
computerThin.addComponentOrReplace(gltfShape15)

const signpostTree = new Entity('signpostTree')
engine.addEntity(signpostTree)
signpostTree.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(59, 4.5, 40),
  rotation: new Quaternion(-2.591818539369778e-15, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(3.0000126361846924, 2, 1.0000030994415283)
})
signpostTree.addComponentOrReplace(transform88)

const videoStream = new Entity('videoStream')
engine.addEntity(videoStream)
videoStream.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(71, 1.5, 34.5),
  rotation: new Quaternion(-2.220446049250313e-16, -0.3826834559440613, 4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(2, 2, 1)
})
videoStream.addComponentOrReplace(transform89)

const tieredDesk2 = new Entity('tieredDesk2')
engine.addEntity(tieredDesk2)
tieredDesk2.setParent(_scene)
tieredDesk2.addComponentOrReplace(gltfShape10)
const transform90 = new Transform({
  position: new Vector3(72, 0.5, 47),
  rotation: new Quaternion(-3.672398163698113e-15, -0.8819212913513184, 1.0513321058169822e-7, 0.47139671444892883),
  scale: new Vector3(1.0000009536743164, 1, 1.0000009536743164)
})
tieredDesk2.addComponentOrReplace(transform90)

const foldingChair2 = new Entity('foldingChair2')
engine.addEntity(foldingChair2)
foldingChair2.setParent(_scene)
foldingChair2.addComponentOrReplace(gltfShape12)
const transform91 = new Transform({
  position: new Vector3(72, 0.5, 44),
  rotation: new Quaternion(8.754096627180627e-16, -0.8819213509559631, 1.0513320347627086e-7, 0.47139665484428406),
  scale: new Vector3(1.0000004768371582, 1, 1.0000004768371582)
})
foldingChair2.addComponentOrReplace(transform91)

const monitorScreen2 = new Entity('monitorScreen2')
engine.addEntity(monitorScreen2)
monitorScreen2.setParent(_scene)
monitorScreen2.addComponentOrReplace(gltfShape11)
const transform92 = new Transform({
  position: new Vector3(72, 1.5, 44.5),
  rotation: new Quaternion(6.230862451429148e-15, -0.9238796234130859, 1.1013501932666259e-7, 0.3826834559440613),
  scale: new Vector3(1.0000040531158447, 1, 1.0000040531158447)
})
monitorScreen2.addComponentOrReplace(transform92)

const enclosedHallJunction = new Entity('enclosedHallJunction')
engine.addEntity(enclosedHallJunction)
enclosedHallJunction.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(39.5, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 2, 1.5)
})
enclosedHallJunction.addComponentOrReplace(transform93)
const gltfShape16 = new GLTFShape("506287b3-c449-4e13-8c1f-705ffd14cb66/Hallway_Big_Module_01/Hallway_Big_Module_01.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
enclosedHallJunction.addComponentOrReplace(gltfShape16)

const signpostTree2 = new Entity('signpostTree2')
engine.addEntity(signpostTree2)
signpostTree2.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(39.5, 7, 27),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(3.5, 2, 1)
})
signpostTree2.addComponentOrReplace(transform94)

const signpostTree3 = new Entity('signpostTree3')
engine.addEntity(signpostTree3)
signpostTree3.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(45.5, 0, 4),
  rotation: new Quaternion(-9.283760622779726e-15, 0.9569403529167175, -1.140761582973937e-7, -0.2902846932411194),
  scale: new Vector3(1.5533473491668701, 1.5, 1.5533473491668701)
})
signpostTree3.addComponentOrReplace(transform95)

const teleport = new Entity('teleport')
engine.addEntity(teleport)
teleport.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(47, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
teleport.addComponentOrReplace(transform96)

const utilityHallway = new Entity('utilityHallway')
engine.addEntity(utilityHallway)
utilityHallway.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(56, 0, 40),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.5000042915344238, 2, 1.5000030994415283)
})
utilityHallway.addComponentOrReplace(transform97)
const gltfShape17 = new GLTFShape("084deb1c-1539-4a75-8f1a-31cd687bc574/Hallway_Module_StraightHalf_01/Hallway_Module_StraightHalf_01.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
utilityHallway.addComponentOrReplace(gltfShape17)

const componentHallway = new Entity('componentHallway')
engine.addEntity(componentHallway)
componentHallway.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(39.5, 0, 51.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 2, 0.75)
})
componentHallway.addComponentOrReplace(transform98)
const gltfShape18 = new GLTFShape("265dfd94-d105-4c50-8a3b-13f9da43d13f/Hallway_Module_Straight_01/Hallway_Module_Straight_01.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
componentHallway.addComponentOrReplace(gltfShape18)

const domeGreenhouse2 = new Entity('domeGreenhouse2')
engine.addEntity(domeGreenhouse2)
domeGreenhouse2.setParent(_scene)
domeGreenhouse2.addComponentOrReplace(gltfShape5)
const transform99 = new Transform({
  position: new Vector3(39.5, 0, 68),
  rotation: new Quaternion(1.40339959298812e-14, 1, -1.1920928955078125e-7, 0),
  scale: new Vector3(2.500000476837158, 2, 2.500000476837158)
})
domeGreenhouse2.addComponentOrReplace(transform99)

const hallwayDoorClosed = new Entity('hallwayDoorClosed')
engine.addEntity(hallwayDoorClosed)
hallwayDoorClosed.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(27.5, 0, 40),
  rotation: new Quaternion(-1.5203487543891635e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(1.5, 2, 1)
})
hallwayDoorClosed.addComponentOrReplace(transform100)
const gltfShape19 = new GLTFShape("43c7d0fb-a8fb-41a5-a9fd-9de37b1fedfe/Hallway_Module_Door_01/Hallway_Module_Door_01.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
hallwayDoorClosed.addComponentOrReplace(gltfShape19)

const lampPost11 = new Entity('lampPost11')
engine.addEntity(lampPost11)
lampPost11.setParent(_scene)
lampPost11.addComponentOrReplace(gltfShape6)
const transform101 = new Transform({
  position: new Vector3(36.5, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost11.addComponentOrReplace(transform101)

const lampPost12 = new Entity('lampPost12')
engine.addEntity(lampPost12)
lampPost12.setParent(_scene)
lampPost12.addComponentOrReplace(gltfShape6)
const transform102 = new Transform({
  position: new Vector3(43.5, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost12.addComponentOrReplace(transform102)

const hexagonalFloorPanel29 = new Entity('hexagonalFloorPanel29')
engine.addEntity(hexagonalFloorPanel29)
hexagonalFloorPanel29.setParent(_scene)
hexagonalFloorPanel29.addComponentOrReplace(gltfShape4)
const transform103 = new Transform({
  position: new Vector3(38, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel29.addComponentOrReplace(transform103)

const hexagonalFloorPanel30 = new Entity('hexagonalFloorPanel30')
engine.addEntity(hexagonalFloorPanel30)
hexagonalFloorPanel30.setParent(_scene)
hexagonalFloorPanel30.addComponentOrReplace(gltfShape4)
const transform104 = new Transform({
  position: new Vector3(40, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel30.addComponentOrReplace(transform104)

const hexagonalFloorPanel31 = new Entity('hexagonalFloorPanel31')
engine.addEntity(hexagonalFloorPanel31)
hexagonalFloorPanel31.setParent(_scene)
hexagonalFloorPanel31.addComponentOrReplace(gltfShape4)
const transform105 = new Transform({
  position: new Vector3(42, 0, 18.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel31.addComponentOrReplace(transform105)

const hexagonalFloorPanel32 = new Entity('hexagonalFloorPanel32')
engine.addEntity(hexagonalFloorPanel32)
hexagonalFloorPanel32.setParent(_scene)
hexagonalFloorPanel32.addComponentOrReplace(gltfShape4)
const transform106 = new Transform({
  position: new Vector3(41, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel32.addComponentOrReplace(transform106)

const hexagonalFloorPanel33 = new Entity('hexagonalFloorPanel33')
engine.addEntity(hexagonalFloorPanel33)
hexagonalFloorPanel33.setParent(_scene)
hexagonalFloorPanel33.addComponentOrReplace(gltfShape4)
const transform107 = new Transform({
  position: new Vector3(39, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel33.addComponentOrReplace(transform107)

const hexagonalFloorPanel34 = new Entity('hexagonalFloorPanel34')
engine.addEntity(hexagonalFloorPanel34)
hexagonalFloorPanel34.setParent(_scene)
hexagonalFloorPanel34.addComponentOrReplace(gltfShape4)
const transform108 = new Transform({
  position: new Vector3(40, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel34.addComponentOrReplace(transform108)

const halfHexFloorPanel13 = new Entity('halfHexFloorPanel13')
engine.addEntity(halfHexFloorPanel13)
halfHexFloorPanel13.setParent(_scene)
halfHexFloorPanel13.addComponentOrReplace(gltfShape8)
const transform109 = new Transform({
  position: new Vector3(43, 0, 20),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel13.addComponentOrReplace(transform109)

const halfHexFloorPanel14 = new Entity('halfHexFloorPanel14')
engine.addEntity(halfHexFloorPanel14)
halfHexFloorPanel14.setParent(_scene)
halfHexFloorPanel14.addComponentOrReplace(gltfShape8)
const transform110 = new Transform({
  position: new Vector3(37, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel14.addComponentOrReplace(transform110)

const hexagonalFloorPanel35 = new Entity('hexagonalFloorPanel35')
engine.addEntity(hexagonalFloorPanel35)
hexagonalFloorPanel35.setParent(_scene)
hexagonalFloorPanel35.addComponentOrReplace(gltfShape4)
const transform111 = new Transform({
  position: new Vector3(38, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel35.addComponentOrReplace(transform111)

const hexagonalFloorPanel36 = new Entity('hexagonalFloorPanel36')
engine.addEntity(hexagonalFloorPanel36)
hexagonalFloorPanel36.setParent(_scene)
hexagonalFloorPanel36.addComponentOrReplace(gltfShape4)
const transform112 = new Transform({
  position: new Vector3(42, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel36.addComponentOrReplace(transform112)

const hexagonalFloorPanel37 = new Entity('hexagonalFloorPanel37')
engine.addEntity(hexagonalFloorPanel37)
hexagonalFloorPanel37.setParent(_scene)
hexagonalFloorPanel37.addComponentOrReplace(gltfShape4)
const transform113 = new Transform({
  position: new Vector3(39, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel37.addComponentOrReplace(transform113)

const halfHexFloorPanel15 = new Entity('halfHexFloorPanel15')
engine.addEntity(halfHexFloorPanel15)
halfHexFloorPanel15.setParent(_scene)
halfHexFloorPanel15.addComponentOrReplace(gltfShape8)
const transform114 = new Transform({
  position: new Vector3(43, 0, 23),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel15.addComponentOrReplace(transform114)

const halfHexFloorPanel16 = new Entity('halfHexFloorPanel16')
engine.addEntity(halfHexFloorPanel16)
halfHexFloorPanel16.setParent(_scene)
halfHexFloorPanel16.addComponentOrReplace(gltfShape8)
const transform115 = new Transform({
  position: new Vector3(37, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel16.addComponentOrReplace(transform115)

const hexagonalFloorPanel38 = new Entity('hexagonalFloorPanel38')
engine.addEntity(hexagonalFloorPanel38)
hexagonalFloorPanel38.setParent(_scene)
hexagonalFloorPanel38.addComponentOrReplace(gltfShape4)
const transform116 = new Transform({
  position: new Vector3(41, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel38.addComponentOrReplace(transform116)

const hexagonalFloorPanel39 = new Entity('hexagonalFloorPanel39')
engine.addEntity(hexagonalFloorPanel39)
hexagonalFloorPanel39.setParent(_scene)
hexagonalFloorPanel39.addComponentOrReplace(gltfShape4)
const transform117 = new Transform({
  position: new Vector3(40, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel39.addComponentOrReplace(transform117)

const halfHexFloorPanel17 = new Entity('halfHexFloorPanel17')
engine.addEntity(halfHexFloorPanel17)
halfHexFloorPanel17.setParent(_scene)
halfHexFloorPanel17.addComponentOrReplace(gltfShape8)
const transform118 = new Transform({
  position: new Vector3(43, 0, 26),
  rotation: new Quaternion(6.721179331408561e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel17.addComponentOrReplace(transform118)

const hexagonalFloorPanel40 = new Entity('hexagonalFloorPanel40')
engine.addEntity(hexagonalFloorPanel40)
hexagonalFloorPanel40.setParent(_scene)
hexagonalFloorPanel40.addComponentOrReplace(gltfShape4)
const transform119 = new Transform({
  position: new Vector3(42, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel40.addComponentOrReplace(transform119)

const hexagonalFloorPanel41 = new Entity('hexagonalFloorPanel41')
engine.addEntity(hexagonalFloorPanel41)
hexagonalFloorPanel41.setParent(_scene)
hexagonalFloorPanel41.addComponentOrReplace(gltfShape4)
const transform120 = new Transform({
  position: new Vector3(38, 0, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel41.addComponentOrReplace(transform120)

const halfHexFloorPanel18 = new Entity('halfHexFloorPanel18')
engine.addEntity(halfHexFloorPanel18)
halfHexFloorPanel18.setParent(_scene)
halfHexFloorPanel18.addComponentOrReplace(gltfShape8)
const transform121 = new Transform({
  position: new Vector3(37, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
halfHexFloorPanel18.addComponentOrReplace(transform121)

const hexagonalFloorPanel42 = new Entity('hexagonalFloorPanel42')
engine.addEntity(hexagonalFloorPanel42)
hexagonalFloorPanel42.setParent(_scene)
hexagonalFloorPanel42.addComponentOrReplace(gltfShape4)
const transform122 = new Transform({
  position: new Vector3(39, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel42.addComponentOrReplace(transform122)

const hexagonalFloorPanel43 = new Entity('hexagonalFloorPanel43')
engine.addEntity(hexagonalFloorPanel43)
hexagonalFloorPanel43.setParent(_scene)
hexagonalFloorPanel43.addComponentOrReplace(gltfShape4)
const transform123 = new Transform({
  position: new Vector3(41, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hexagonalFloorPanel43.addComponentOrReplace(transform123)

const lampPost13 = new Entity('lampPost13')
engine.addEntity(lampPost13)
lampPost13.setParent(_scene)
lampPost13.addComponentOrReplace(gltfShape6)
const transform124 = new Transform({
  position: new Vector3(36.5, 0, 17),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost13.addComponentOrReplace(transform124)

const lampPost14 = new Entity('lampPost14')
engine.addEntity(lampPost14)
lampPost14.setParent(_scene)
lampPost14.addComponentOrReplace(gltfShape6)
const transform125 = new Transform({
  position: new Vector3(36.5, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost14.addComponentOrReplace(transform125)

const lampPost15 = new Entity('lampPost15')
engine.addEntity(lampPost15)
lampPost15.setParent(_scene)
lampPost15.addComponentOrReplace(gltfShape6)
const transform126 = new Transform({
  position: new Vector3(36.5, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost15.addComponentOrReplace(transform126)

const lampPost16 = new Entity('lampPost16')
engine.addEntity(lampPost16)
lampPost16.setParent(_scene)
lampPost16.addComponentOrReplace(gltfShape6)
const transform127 = new Transform({
  position: new Vector3(36.5, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost16.addComponentOrReplace(transform127)

const lampPost17 = new Entity('lampPost17')
engine.addEntity(lampPost17)
lampPost17.setParent(_scene)
lampPost17.addComponentOrReplace(gltfShape6)
const transform128 = new Transform({
  position: new Vector3(43.5, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost17.addComponentOrReplace(transform128)

const lampPost18 = new Entity('lampPost18')
engine.addEntity(lampPost18)
lampPost18.setParent(_scene)
lampPost18.addComponentOrReplace(gltfShape6)
const transform129 = new Transform({
  position: new Vector3(43.5, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost18.addComponentOrReplace(transform129)

const lampPost19 = new Entity('lampPost19')
engine.addEntity(lampPost19)
lampPost19.setParent(_scene)
lampPost19.addComponentOrReplace(gltfShape6)
const transform130 = new Transform({
  position: new Vector3(43.5, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lampPost19.addComponentOrReplace(transform130)

const spaceshipPlatform = new Entity('spaceshipPlatform')
engine.addEntity(spaceshipPlatform)
spaceshipPlatform.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(53, 0, 21.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
spaceshipPlatform.addComponentOrReplace(transform131)
const gltfShape20 = new GLTFShape("1ebcf4b9-c78c-4211-8229-069fc0c405b5/SpaceShipBase_01/SpaceShipBase_01.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
spaceshipPlatform.addComponentOrReplace(gltfShape20)

const orangeSpacePod = new Entity('orangeSpacePod')
engine.addEntity(orangeSpacePod)
orangeSpacePod.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(53, 2, 21),
  rotation: new Quaternion(-3.2954483851374517e-15, 0.9238795638084412, -1.1013500511580787e-7, -0.3826834559440613),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
orangeSpacePod.addComponentOrReplace(transform132)
const gltfShape21 = new GLTFShape("6914faa3-2f1d-4796-9d47-c5bda933fa52/SpaceShip_01/SpaceShip_01.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
orangeSpacePod.addComponentOrReplace(gltfShape21)

const vault = new Entity('vault')
engine.addEntity(vault)
vault.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(11.5, 0, 73),
  rotation: new Quaternion(-5.9992582326614044e-15, -1, 1.1920927533992653e-7, -8.940696716308594e-8),
  scale: new Vector3(11.249998092651367, 7.5, 7.500003337860107)
})
vault.addComponentOrReplace(transform133)
const gltfShape22 = new GLTFShape("bf8da23c-113b-4a20-a201-8e62dd56091f/Vault_01/Vault_01.glb")
gltfShape22.withCollisions = true
gltfShape22.isPointerBlocker = true
gltfShape22.visible = true
vault.addComponentOrReplace(gltfShape22)

const vault2 = new Entity('vault2')
engine.addEntity(vault2)
vault2.setParent(_scene)
vault2.addComponentOrReplace(gltfShape22)
const transform134 = new Transform({
  position: new Vector3(69, 0, 72.5),
  rotation: new Quaternion(-5.9992582326614044e-15, -1, 1.1920927533992653e-7, -8.940696716308594e-8),
  scale: new Vector3(11.249998092651367, 7.5, 7.500003337860107)
})
vault2.addComponentOrReplace(transform134)

const vault3 = new Entity('vault3')
engine.addEntity(vault3)
vault3.setParent(_scene)
vault3.addComponentOrReplace(gltfShape22)
const transform135 = new Transform({
  position: new Vector3(5.5, 0, 43.5),
  rotation: new Quaternion(4.242116335669618e-15, 0.7071067690849304, -8.429368136830817e-8, 0.7071068286895752),
  scale: new Vector3(28.12499237060547, 7.5, 3.8250012397766113)
})
vault3.addComponentOrReplace(transform135)

const noIMAGE = new Entity('noIMAGE')
engine.addEntity(noIMAGE)
noIMAGE.setParent(_scene)
const transform136 = new Transform({
  position: new Vector3(26, 0, 15),
  rotation: new Quaternion(-9.208323868497258e-16, 0.7071067690849304, -8.429370268459024e-8, 0.70710688829422),
  scale: new Vector3(1.0000014305114746, 1, 1.0000014305114746)
})
noIMAGE.addComponentOrReplace(transform136)
const gltfShape23 = new GLTFShape("ea601b6c-3d21-4c34-b4cb-620c7022d3a2/GreenHouse_02/GreenHouse_02.glb")
gltfShape23.withCollisions = true
gltfShape23.isPointerBlocker = true
gltfShape23.visible = true
noIMAGE.addComponentOrReplace(gltfShape23)

const cryogenicChamberBase = new Entity('cryogenicChamberBase')
engine.addEntity(cryogenicChamberBase)
cryogenicChamberBase.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(68, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
cryogenicChamberBase.addComponentOrReplace(transform137)
const gltfShape24 = new GLTFShape("771f67cd-fe43-496a-9425-c55ed54afd84/CryogenicChamberBase_01/CryogenicChamberBase_01.glb")
gltfShape24.withCollisions = true
gltfShape24.isPointerBlocker = true
gltfShape24.visible = true
cryogenicChamberBase.addComponentOrReplace(gltfShape24)

const yellowBuds = new Entity('yellowBuds')
engine.addEntity(yellowBuds)
yellowBuds.setParent(_scene)
const transform138 = new Transform({
  position: new Vector3(20, 0, 36.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.399998664855957, 9, 9.50000286102295)
})
yellowBuds.addComponentOrReplace(transform138)
const gltfShape25 = new GLTFShape("f18f23b1-dce3-426b-8039-3fd7a5100862/PlantSF_02/PlantSF_02.glb")
gltfShape25.withCollisions = true
gltfShape25.isPointerBlocker = true
gltfShape25.visible = true
yellowBuds.addComponentOrReplace(gltfShape25)

const yellowBuds2 = new Entity('yellowBuds2')
engine.addEntity(yellowBuds2)
yellowBuds2.setParent(_scene)
yellowBuds2.addComponentOrReplace(gltfShape25)
const transform139 = new Transform({
  position: new Vector3(54.5, 0, 58),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.399998664855957, 9, 9.50000286102295)
})
yellowBuds2.addComponentOrReplace(transform139)

const yellowBuds3 = new Entity('yellowBuds3')
engine.addEntity(yellowBuds3)
yellowBuds3.setParent(_scene)
yellowBuds3.addComponentOrReplace(gltfShape25)
const transform140 = new Transform({
  position: new Vector3(77, 0, 27.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(10.399998664855957, 9, 9.50000286102295)
})
yellowBuds3.addComponentOrReplace(transform140)

const turquoiseAcaciaTree = new Entity('turquoiseAcaciaTree')
engine.addEntity(turquoiseAcaciaTree)
turquoiseAcaciaTree.setParent(_scene)
const transform141 = new Transform({
  position: new Vector3(58, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
turquoiseAcaciaTree.addComponentOrReplace(transform141)
const gltfShape26 = new GLTFShape("f8608443-f44d-4505-957c-3d1bfddb6a5a/Tree_Forest_Turquoise_01/Tree_Forest_Turquoise_01.glb")
gltfShape26.withCollisions = true
gltfShape26.isPointerBlocker = true
gltfShape26.visible = true
turquoiseAcaciaTree.addComponentOrReplace(gltfShape26)

const tallTurquoiseAcaciaTree = new Entity('tallTurquoiseAcaciaTree')
engine.addEntity(tallTurquoiseAcaciaTree)
tallTurquoiseAcaciaTree.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(74.5, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
tallTurquoiseAcaciaTree.addComponentOrReplace(transform142)
const gltfShape27 = new GLTFShape("b0787719-7d9a-47f0-951f-23963a8fd274/Tree_Forest_Turquoise_04/Tree_Forest_Turquoise_04.glb")
gltfShape27.withCollisions = true
gltfShape27.isPointerBlocker = true
gltfShape27.visible = true
tallTurquoiseAcaciaTree.addComponentOrReplace(gltfShape27)

const clusteredTurquoiseAcaciaTree = new Entity('clusteredTurquoiseAcaciaTree')
engine.addEntity(clusteredTurquoiseAcaciaTree)
clusteredTurquoiseAcaciaTree.setParent(_scene)
const transform143 = new Transform({
  position: new Vector3(20, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clusteredTurquoiseAcaciaTree.addComponentOrReplace(transform143)
const gltfShape28 = new GLTFShape("e0320530-0990-4941-996b-7ca039c7db3d/Tree_Forest_Turquoise_03/Tree_Forest_Turquoise_03.glb")
gltfShape28.withCollisions = true
gltfShape28.isPointerBlocker = true
gltfShape28.visible = true
clusteredTurquoiseAcaciaTree.addComponentOrReplace(gltfShape28)

const bloomingTurquoiseAcaciaTree = new Entity('bloomingTurquoiseAcaciaTree')
engine.addEntity(bloomingTurquoiseAcaciaTree)
bloomingTurquoiseAcaciaTree.setParent(_scene)
const transform144 = new Transform({
  position: new Vector3(73, 0, 54.5),
  rotation: new Quaternion(0, 0.2902846932411194, -3.4604628496026635e-8, 0.9569403529167175),
  scale: new Vector3(1, 1, 1)
})
bloomingTurquoiseAcaciaTree.addComponentOrReplace(transform144)
const gltfShape29 = new GLTFShape("af393f91-905e-4d1c-9c26-e11a5d84e4c9/Tree_Forest_Turquoise_02/Tree_Forest_Turquoise_02.glb")
gltfShape29.withCollisions = true
gltfShape29.isPointerBlocker = true
gltfShape29.visible = true
bloomingTurquoiseAcaciaTree.addComponentOrReplace(gltfShape29)

const bloomingTurquoiseAcaciaTree2 = new Entity('bloomingTurquoiseAcaciaTree2')
engine.addEntity(bloomingTurquoiseAcaciaTree2)
bloomingTurquoiseAcaciaTree2.setParent(_scene)
const transform145 = new Transform({
  position: new Vector3(27.5, 0, 53),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bloomingTurquoiseAcaciaTree2.addComponentOrReplace(transform145)
bloomingTurquoiseAcaciaTree2.addComponentOrReplace(gltfShape29)

const clusteredTurquoiseAcaciaTree2 = new Entity('clusteredTurquoiseAcaciaTree2')
engine.addEntity(clusteredTurquoiseAcaciaTree2)
clusteredTurquoiseAcaciaTree2.setParent(_scene)
const transform146 = new Transform({
  position: new Vector3(64, 0, 19.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clusteredTurquoiseAcaciaTree2.addComponentOrReplace(transform146)
clusteredTurquoiseAcaciaTree2.addComponentOrReplace(gltfShape28)

const tallTurquoiseAcaciaTree2 = new Entity('tallTurquoiseAcaciaTree2')
engine.addEntity(tallTurquoiseAcaciaTree2)
tallTurquoiseAcaciaTree2.setParent(_scene)
const transform147 = new Transform({
  position: new Vector3(33.5, 0, 26),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
tallTurquoiseAcaciaTree2.addComponentOrReplace(transform147)
tallTurquoiseAcaciaTree2.addComponentOrReplace(gltfShape27)

const turquoiseAcaciaTree2 = new Entity('turquoiseAcaciaTree2')
engine.addEntity(turquoiseAcaciaTree2)
turquoiseAcaciaTree2.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(24.5, 0, 29.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
turquoiseAcaciaTree2.addComponentOrReplace(transform148)
turquoiseAcaciaTree2.addComponentOrReplace(gltfShape26)

const bloomingTurquoiseAcaciaTree3 = new Entity('bloomingTurquoiseAcaciaTree3')
engine.addEntity(bloomingTurquoiseAcaciaTree3)
bloomingTurquoiseAcaciaTree3.setParent(_scene)
bloomingTurquoiseAcaciaTree3.addComponentOrReplace(gltfShape29)
const transform149 = new Transform({
  position: new Vector3(53, 0, 28),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bloomingTurquoiseAcaciaTree3.addComponentOrReplace(transform149)

const imageBillboardWhite = new Entity('imageBillboardWhite')
engine.addEntity(imageBillboardWhite)
imageBillboardWhite.setParent(_scene)
const transform150 = new Transform({
  position: new Vector3(11.5, 0, 27.5),
  rotation: new Quaternion(-2.617561352944494e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(2.883601665496826, 3.5, 3.784703493118286)
})
imageBillboardWhite.addComponentOrReplace(transform150)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script1.spawn(signpostTree, {"text":"Computer Science Learning Lab","fontSize":19}, createChannel(channelId, signpostTree, channelBus))
script2.spawn(videoStream, {"startOn":"false","onClickText":"Play video","volume":1,"onClick":[{"entityName":"videoStream","actionId":"toggle","values":{}}],"customStation":"https://www.youtube.com/watch?v=-P9kjI1Hxio","station":"https://theuniverse.club/live/genesisplaza/index.m3u8"}, createChannel(channelId, videoStream, channelBus))
script1.spawn(signpostTree2, {"text":"EY FUTURE HUB","fontSize":30}, createChannel(channelId, signpostTree2, channelBus))
script3.spawn(signpostTree3, {"text":"Welcome to EVR","fontSize":20}, createChannel(channelId, signpostTree3, channelBus))
script4.spawn(teleport, {"x":"0","y":"0"}, createChannel(channelId, teleport, channelBus))
script5.spawn(imageBillboardWhite, {"image":"https://cdn.discordapp.com/attachments/633201642719805440/949961702164824074/microsoft_logo.png"}, createChannel(channelId, imageBillboardWhite, channelBus))